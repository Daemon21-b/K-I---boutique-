<img src="img/logo.png" alt="K_I Boutique" class="logo">
